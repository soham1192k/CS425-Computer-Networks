#include<bits/stdc++.h>
using namespace std;
//required function
int get_crc(vector<int>msg,vector<int>p,int k){
    int dividend=0;
    for(int i=0;i<k;i++){
        if(msg[i]==1){
            dividend+=(1<<(k-1-i));
        }
    }
    int divisor=0;
    for(int i=0;i<(int)p.size();i++){
        if(p[i]==1){
            divisor+=(1<<(p.size()-i));
        }
    }
    int degree = (int)p.size()-1;
    divisor = divisor<<(k-degree-1);
    divisor = divisor<<degree;
    int remainder = dividend<<degree;
    for(int i=1;i<=k;i++){
        if(remainder&(1<<(k+degree))) remainder = (remainder^divisor)<<1;
        else remainder = remainder<<1;
    }
    int crc_val = remainder>>k;
    return crc_val;
}
string dec2bin(int n){
    string s="";
    while(n!=1){
        s+=(n%2)+'0';
        n/=2;
    }
    s+='1';
    reverse(s.begin(),s.end());
    return s;
}
int main(){
    int k = 10;
    //Generating 10 random bits
    vector<int>msg(k);
    for(int i=0;i<k;i++){
        float val = (float)rand()/RAND_MAX;
        if(val<0.5) msg[i]=0;
        else msg[i]=1;
    }
    cout<<"Transmitted Message---> ";
    for(int i=0;i<k;i++) cout<<msg[i]<<" ";
    cout<<'\n';
    int dividend = 0;
    for(int i=0;i<k;i++){
        if(msg[i]==1){
            dividend+=(1<<(k-1-i));
        }
    }
    string temp = "110101";
    int divisor = 0;
    for(int i=0;i<(int)temp.length();i++){
        if(temp[i]=='1'){
            divisor+=(1<<(temp.length()-i));
        }
    }
    cout<<"Divisor--> ";
    for(int i=0;i<(int)temp.length();i++) cout<<temp[i]<<" ";  
    cout<<'\n';
    int degree = 5;
    cout<<"CRC_VALUE--> ";
    vector<int>p;
    for(int i=0;i<temp.length();i++) p.push_back(temp[i]-'0');
    int crc_val = get_crc(msg,p,k);
    string s = dec2bin(crc_val);
    for(int i=0;i<s.length();i++) cout<<s[i]<<" ";
    cout<<'\n';
    int codeword = (dividend<<degree)|crc_val;
    cout<<"Codeword--> ";
    s = dec2bin(codeword);
    for(int i=0;i<s.length();i++) cout<<s[i]<<" ";
    cout<<'\n';
    //Generate a 15 bit error stream randomly
    vector<int>error_stream(k+degree);
    for(int i=0;i<k+degree;i++){
        float val = (float)rand()/RAND_MAX;
        if(val<0.5) error_stream[i]=0;
        else error_stream[i]=1;
    }
    cout<<"Error Stream--> ";
    for(int i=0;i<error_stream.size();i++) cout<<error_stream[i]<<" ";
    cout<<'\n';
    int err_val = 0;
    for(int i=0;i<error_stream.size();i++){
        if(error_stream[i]==1) err_val+=(1<<(error_stream.size()-1-i));
    }
    int remainder = codeword^err_val;
    cout<<"Recieved Message--> ";
    s = dec2bin(remainder);
    for(int i=0;i<s.length();i++) cout<<s[i]<<" ";
    cout<<'\n';
    for(int i=1;i<=k;i++){
        if(remainder&(1<<(k+degree))) remainder = (remainder^divisor)<<1;
        else remainder = remainder<<1;
    }
    if(remainder==0) cout<<"Accepted -- error free\n";
    else cout<<"Rejected -- contains errrors\n";

    //Testing with 2 sets of inputs
    // vector<int>x={1,1,1,0,0,0,1,1};
    // vector<int>xx={1,1,0,0,1,1};
    // cout<<get_crc(x,xx,8)<<'\n';
    
    // x={1,0,0,1,0,0,1,1,0,1,1};
    // xx={1,0,0,1,1};
    // cout<<get_crc(x,xx,11)<<'\n';
    return 0;
}
 

