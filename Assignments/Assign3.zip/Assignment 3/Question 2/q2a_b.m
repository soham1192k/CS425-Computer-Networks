clc;
clear all;
close all;

ts=1.e-4;
t=-0.04:ts:0.04;
A=1; %Amplitude
w=200; %Frequency
phi=0; %Phase
m_sig=A*sin(w*t+phi); %Message Signal

Lfft=length(t);
Lfft=2^ceil(log2(Lfft));
M_sig=fftshift(fft(m_sig,Lfft));
freqm=(-Lfft/2:Lfft/2-1)/(Lfft*ts);

kf=80*pi; %Frequency modulation index
kp=1; %Phase modulation index
fc=300; %Carrier Frequency
m_intg=kf*ts*cumsum(m_sig);
s_fm=cos(2*pi*fc*t+m_intg);
s_pm=cos(2*pi*fc*t+kp*pi*m_sig);

Lfft=length(t);
Lfft=2^ceil(log2(Lfft));
S_fm=fftshift(fft(s_fm,Lfft));
S_pm=fftshift(fft(s_pm,Lfft));
freqs=(-Lfft/2:Lfft/2-1)/(Lfft*ts);

figure(1);
subplot(311);
plot(t,m_sig,'LineWidth',2);
grid on;
axis([-0.04 0.04 -2 2]);
xlabel('t(sec)');
ylabel('m(t)');
title('Message signal in time domain');

subplot(312);
plot(t,s_fm,'LineWidth',2);
grid on;
axis([-0.04 0.04 -2 2]);
xlabel('t(sec)');
ylabel('s\_FM(t)');
title('FM signal in time domain');

subplot(313);
plot(t,s_pm,'LineWidth',2);
grid on;
axis([-0.04 0.04 -2 2]);
xlabel('t(sec)');
ylabel('s\_PM(t)');
title('PM signal in time domain');

figure(2);
subplot(311);
plot(freqs,abs(M_sig),'LineWidth',2);
grid on;
axis([-600 600 0 400]);
xlabel('f(Hz)');
ylabel('M(f)');
title('Message signal in frequency domain');

subplot(312);
plot(freqs,abs(S_fm),'LineWidth',2);
grid on;
axis([-600 600 0 400]);
xlabel('f(Hz)');
ylabel('S\_FM(f)');
title('FM signal in frequency domain');

subplot(313);
plot(freqs,abs(S_pm),'LineWidth',2);
grid on;
axis([-600 600 0 400]);
xlabel('f(Hz)');
ylabel('S\_PM(f)');
title('PM signal in frequency domain');