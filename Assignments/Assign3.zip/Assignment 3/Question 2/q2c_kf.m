clc;
clear all;
close all;

ts=1.e-4;
t=-0.04:ts:0.04;
A=1; %Amplitude
w=200; %Frequency
phi=0; %Phase
m_sig=A*sin(w*t+phi); %Message Signal

Lfft=length(t);
Lfft=2^ceil(log2(Lfft));
M_sig=fftshift(fft(m_sig,Lfft));
freqm=(-Lfft/2:Lfft/2-1)/(Lfft*ts);

kf=0; %Frequency modulation index
kp=1; %Phase modulation index
fc=300; %Carrier Frequency
m_intg=kf*ts*cumsum(m_sig);
s_fm=cos(2*pi*fc*t+m_intg);
s_pm=cos(2*pi*fc*t+kp*pi*m_sig);

Lfft=length(t);
Lfft=2^ceil(log2(Lfft));
S_fm=fftshift(fft(s_fm,Lfft));
S_pm=fftshift(fft(s_pm,Lfft));
freqs=(-Lfft/2:Lfft/2-1)/(Lfft*ts);

figure(1);
subplot(411);
plot(freqs,abs(S_fm),'LineWidth',2);
grid on;
axis([-600 600 0 400]);
xlabel('f(Hz)');
ylabel('S\_FM(f)');
title('FM signal in frequency domain, kf=0');

kf=150*pi; %Frequency modulation index
kp=1; %Phase modulation index
fc=300; %Carrier Frequency
m_intg=kf*ts*cumsum(m_sig);
s_fm=cos(2*pi*fc*t+m_intg);
s_pm=cos(2*pi*fc*t+kp*pi*m_sig);

Lfft=length(t);
Lfft=2^ceil(log2(Lfft));
S_fm=fftshift(fft(s_fm,Lfft));
S_pm=fftshift(fft(s_pm,Lfft));
freqs=(-Lfft/2:Lfft/2-1)/(Lfft*ts);

subplot(412);
plot(freqs,abs(S_fm),'LineWidth',2);
grid on;
axis([-600 600 0 400]);
xlabel('f(Hz)');
ylabel('S\_FM(f)');
title('FM signal in frequency domain, kf=150');

kf=300*pi; %Frequency modulation index
kp=1; %Phase modulation index
fc=300; %Carrier Frequency
m_intg=kf*ts*cumsum(m_sig);
s_fm=cos(2*pi*fc*t+m_intg);
s_pm=cos(2*pi*fc*t+kp*pi*m_sig);

Lfft=length(t);
Lfft=2^ceil(log2(Lfft));
S_fm=fftshift(fft(s_fm,Lfft));
S_pm=fftshift(fft(s_pm,Lfft));
freqs=(-Lfft/2:Lfft/2-1)/(Lfft*ts);

subplot(413);
plot(freqs,abs(S_fm),'LineWidth',2);
grid on;
axis([-600 600 0 400]);
xlabel('f(Hz)');
ylabel('S\_FM(f)');
title('FM signal in frequency domain, kf=300');

kf=500*pi; %Frequency modulation index
kp=1; %Phase modulation index
fc=300; %Carrier Frequency
m_intg=kf*ts*cumsum(m_sig);
s_fm=cos(2*pi*fc*t+m_intg);
s_pm=cos(2*pi*fc*t+kp*pi*m_sig);

Lfft=length(t);
Lfft=2^ceil(log2(Lfft));
S_fm=fftshift(fft(s_fm,Lfft));
S_pm=fftshift(fft(s_pm,Lfft));
freqs=(-Lfft/2:Lfft/2-1)/(Lfft*ts);

subplot(414);
plot(freqs,abs(S_fm),'LineWidth',2);
grid on;
axis([-600 600 0 400]);
xlabel('f(Hz)');
ylabel('S\_FM(f)');
title('FM signal in frequency domain, kf=500');