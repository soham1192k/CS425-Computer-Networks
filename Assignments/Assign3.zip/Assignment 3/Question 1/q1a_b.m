clc;
clear all;
close all;

ts=10^(-4);
t=-0.04:ts:0.04;
A=1; %Amplitude
w=200; %Frequency
phi=0; %Phase
m_sig=A*sin(w*t+phi); %Message Signal

Lfft=length(t);
Lfft=2^ceil(log2(Lfft));
M_sig=fftshift(fft(m_sig,Lfft));
freqm=(-Lfft/2:Lfft/2-1)/(Lfft*ts);

ka=2.5; %Modulation Index
fc=300; %Carrier Frequency
s_am=(1+ka*m_sig).*cos(2*pi*fc*t);

Lfft=length(t);
Lfft=2^ceil(log2(Lfft)+1);
S_am=fftshift(fft(s_am,Lfft));
freqs=(-Lfft/2:Lfft/2-1)/(Lfft*ts);

figure(1);
subplot(211);
plot(t,m_sig,'LineWidth',2);
grid on;
axis([-0.04 0.04 -2 2]);
xlabel('t(sec)');
ylabel('m(t)');
title('Message signal in time domain');

subplot(212);
plot(t,s_am,'LineWidth',2);
grid on;
hold on;
plot(t,1+ka*m_sig, 'r:','LineWidth',2);
plot(t,-1-ka*m_sig, 'r:','LineWidth',2);
axis([-0.04 0.04 -4 4]);
xlabel('t(sec)');
ylabel('s\_AM(t)');
title('AM signal in time domain');

figure(2);
subplot(211);
plot(freqm,abs(M_sig),'LineWidth',2);
grid on;
axis([-600 600 0 400]);
xlabel('f(Hz)');
ylabel('M(f)');
title('Message signal in frequency domain');

subplot(212);
plot(freqs,abs(S_am),'LineWidth',2);
grid on;
axis([-600 600 0 600]);
xlabel('f(Hz)');
ylabel('S\_AM(f)');
title('AM signal in frequency domain');