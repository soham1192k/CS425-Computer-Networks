clc;
clear all;
close all;

ts=10^(-4);
t=-0.04:ts:0.04;
A=1; %Amplitude
w=200; %Frequency
phi=0; %Phase
m_sig=A*sin(w*t+phi); %Message Signal

Lfft=length(t);
Lfft=2^ceil(log2(Lfft));
M_sig=fftshift(fft(m_sig,Lfft));
freqm=(-Lfft/2:Lfft/2-1)/(Lfft*ts);

ka=0; %Modulation Index
fc=300; %Carrier Frequency
s_am=(1+ka*m_sig).*cos(2*pi*fc*t);

Lfft=length(t);
Lfft=2^ceil(log2(Lfft)+1);
S_am=fftshift(fft(s_am,Lfft));
freqs=(-Lfft/2:Lfft/2-1)/(Lfft*ts);

figure(1);
subplot(411);
plot(t,s_am,'LineWidth',2);
grid on;
hold on;
plot(t,1+ka*m_sig, 'r:');
plot(t,-1-ka*m_sig, 'r:');
axis([-0.04 0.04 -4 4]);
xlabel('t(sec)');
ylabel('s\_AM(t)');
title('AM signal in time domain, Modulation Index=0');

figure(2);
subplot(411);
plot(freqs,abs(S_am),'LineWidth',2);
grid on;
axis([-400 400 0 600]);
xlabel('f(Hz)');
ylabel('S\_AM(f)');
title('AM signal in frequency domain, Modulation Index=0');

ka=0.5; %Modulation Index
fc=300; %Carrier Frequency
s_am=(1+ka*m_sig).*cos(2*pi*fc*t);

Lfft=length(t);
Lfft=2^ceil(log2(Lfft)+1);
S_am=fftshift(fft(s_am,Lfft));
freqs=(-Lfft/2:Lfft/2-1)/(Lfft*ts);

figure(1);
subplot(412);
plot(t,s_am,'LineWidth',2);
grid on;
hold on;
plot(t,1+ka*m_sig, 'r:');
plot(t,-1-ka*m_sig, 'r:');
axis([-0.04 0.04 -4 4]);
xlabel('t(sec)');
ylabel('s\_AM(t)');
title('AM signal in time domain, Modulation Index=0.5');

figure(2);
subplot(412);
plot(freqs,abs(S_am),'LineWidth',2);
grid on;
axis([-400 400 0 600]);
xlabel('f(Hz)');
ylabel('S\_AM(f)');
title('AM signal in frequency domain, Modulation Index=0.5');

ka=1; %Modulation Index
fc=300; %Carrier Frequency
s_am=(1+ka*m_sig).*cos(2*pi*fc*t);

Lfft=length(t);
Lfft=2^ceil(log2(Lfft)+1);
S_am=fftshift(fft(s_am,Lfft));
freqs=(-Lfft/2:Lfft/2-1)/(Lfft*ts);

figure(1);
subplot(413);
plot(t,s_am,'LineWidth',2);
grid on;
hold on;
plot(t,1+ka*m_sig, 'r:');
plot(t,-1-ka*m_sig, 'r:');
axis([-0.04 0.04 -4 4]);
xlabel('t(sec)');
ylabel('s\_AM(t)');
title('AM signal in time domain, Modulation Index=1');

figure(2);
subplot(413);
plot(freqs,abs(S_am),'LineWidth',2);
grid on;
axis([-400 400 0 600]);
xlabel('f(Hz)');
ylabel('S\_AM(f)');
title('AM signal in frequency domain, Modulation Index=1');

ka=2; %Modulation Index
fc=300; %Carrier Frequency
s_am=(1+ka*m_sig).*cos(2*pi*fc*t);

Lfft=length(t);
Lfft=2^ceil(log2(Lfft)+1);
S_am=fftshift(fft(s_am,Lfft));
freqs=(-Lfft/2:Lfft/2-1)/(Lfft*ts);

figure(1);
subplot(414);
plot(t,s_am,'LineWidth',2);
grid on;
hold on;
plot(t,1+ka*m_sig, 'r:');
plot(t,-1-ka*m_sig, 'r:');
axis([-0.04 0.04 -4 4]);
xlabel('t(sec)');
ylabel('s\_AM(t)');
title('AM signal in time domain, Modulation Index=2');

figure(2);
subplot(414);
plot(freqs,abs(S_am),'LineWidth',2);
grid on;
axis([-400 400 0 600]);
xlabel('f(Hz)');
ylabel('S\_AM(f)');
title('AM signal in frequency domain, Modulation Index=2');